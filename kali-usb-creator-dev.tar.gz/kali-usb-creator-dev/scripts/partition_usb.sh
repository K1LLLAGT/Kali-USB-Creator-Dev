#!/usr/bin/env bash
# partition_usb.sh — PRODUCTION: add a persistence partition in the free space
# after a flashed isohybrid ISO. Run AFTER flash_iso.sh.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib_common.sh
source "${LIB_DIR:-$SCRIPT_DIR}/lib_common.sh"

: "${TARGET_DEVICE:?TARGET_DEVICE not set}"
PERSIST_SIZE_MB="${PERSIST_SIZE_MB:-4096}"

require_cmd parted partprobe sync || exit 1

assert_safe_target "$TARGET_DEVICE"

warn "Creating a ${PERSIST_SIZE_MB} MB persistence partition on ${TARGET_DEVICE}."
warn "This assumes the ISO has already been flashed to this device."
confirm_device "$TARGET_DEVICE"

# Create a new primary partition spanning from the end of the ISO image to the
# requested size. parted's free-space placement starts the new partition after
# existing ones; 'mkpart' with start '0%' of remaining is not portable, so we
# append explicitly using the last sector reported by parted.
info "Creating persistence partition..."
# Append a partition that ends PERSIST_SIZE_MB from the current end of data.
run_cmd parted -s "$TARGET_DEVICE" mkpart primary ext4 -- -"${PERSIST_SIZE_MB}"MiB 100%
run_cmd partprobe "$TARGET_DEVICE"
run_cmd sync

symlog "💾" "Persistence partition created on ${TARGET_DEVICE}"
ok "Production partition step complete."
