#!/usr/bin/env bash
# mockflashiso.sh — simulate flashing an ISO into the mock usb.img
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib_common.sh
source "${LIB_DIR:-$SCRIPT_DIR}/lib_common.sh"

: "${USB_IMG:?USB_IMG not set}"

require_cmd dd || exit 1

if [[ ! -f "$USB_IMG" ]] && ! is_dry; then
    die "Mock USB image ${USB_IMG} not found — run the partition step first."
fi

# If a real ISO path is configured, sip a chunk from it so the simulation is
# representative; otherwise write zeroes to stand in for the boot region.
src="/dev/zero"
if [[ -n "${ISO_PATH:-}" && -f "${ISO_PATH:-}" ]]; then
    src="$ISO_PATH"
    info "Mock flash: sampling boot region from $(basename "$ISO_PATH")"
else
    info "Mock flash: writing simulated boot region (no ISO_PATH set)"
fi

run_cmd dd if="$src" of="$USB_IMG" bs=1M count=4 conv=notrunc status=none

symlog "📀" "ISO flash simulation complete"
ok "Mock ISO flash done."
