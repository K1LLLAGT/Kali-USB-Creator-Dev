#!/usr/bin/env bash
# flash_iso.sh — PRODUCTION: write an isohybrid Kali ISO to TARGET_DEVICE.
# DESTRUCTIVE. Overwrites the entire device.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib_common.sh
source "${LIB_DIR:-$SCRIPT_DIR}/lib_common.sh"

: "${TARGET_DEVICE:?TARGET_DEVICE not set}"
: "${ISO_PATH:?ISO_PATH not set}"

require_cmd dd sync findmnt lsblk || exit 1

[[ -f "$ISO_PATH" ]] || die "ISO not found: $ISO_PATH"
assert_safe_target "$TARGET_DEVICE"

warn "About to OVERWRITE ${TARGET_DEVICE} with ${ISO_PATH}."
lsblk -o NAME,SIZE,TYPE,MOUNTPOINT "$TARGET_DEVICE" 2>/dev/null || true
confirm_device "$TARGET_DEVICE"

# Make sure nothing on the target is mounted.
if findmnt -rn -S "$TARGET_DEVICE" >/dev/null 2>&1 || \
   lsblk -nro MOUNTPOINT "$TARGET_DEVICE" | grep -q . ; then
    warn "Target has mounted partitions; attempting to unmount."
    while read -r part; do
        [[ -n "$part" ]] && run_cmd umount "/dev/$part" 2>/dev/null || true
    done < <(lsblk -nro NAME "$TARGET_DEVICE" | tail -n +2)
fi

info "Flashing ISO (this can take several minutes)..."
run_cmd dd if="$ISO_PATH" of="$TARGET_DEVICE" bs=4M conv=fsync oflag=direct status=progress
run_cmd sync

symlog "📀" "ISO flashed to ${TARGET_DEVICE}"
ok "Production ISO flash complete."
