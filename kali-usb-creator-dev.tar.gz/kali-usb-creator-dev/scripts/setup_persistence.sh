#!/usr/bin/env bash
# setup_persistence.sh — PRODUCTION: format the persistence partition with the
# label Kali expects and write the persistence.conf union rule.
# Run AFTER partition_usb.sh.
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib_common.sh
source "${LIB_DIR:-$SCRIPT_DIR}/lib_common.sh"

: "${TARGET_DEVICE:?TARGET_DEVICE not set}"
PERSIST_LABEL="${PERSIST_LABEL:-persistence}"

require_cmd mkfs.ext4 mount umount lsblk sync || exit 1

assert_safe_target "$TARGET_DEVICE"

# The persistence partition is the last partition on the device.
last_part="$(lsblk -nro NAME "$TARGET_DEVICE" | tail -n1)"
[[ -n "$last_part" && "/dev/$last_part" != "$TARGET_DEVICE" ]] \
    || die "Could not identify the persistence partition on ${TARGET_DEVICE}."
part="/dev/$last_part"

warn "Formatting ${part} as ext4 with label '${PERSIST_LABEL}'."
confirm_device "$part"

run_cmd mkfs.ext4 -F -L "$PERSIST_LABEL" "$part"

mnt="$(mktemp -d)"
info "Writing persistence.conf union rule..."
if is_dry; then
    log "DRY_RUN: would mount $part, write '/ union' to persistence.conf, unmount"
else
    mount "$part" "$mnt"
    printf '/ union\n' > "$mnt/persistence.conf"
    sync
    umount "$mnt"
fi
rmdir "$mnt" 2>/dev/null || true

symlog "🧩" "Persistence configured on ${part}"
ok "Production persistence setup complete."
