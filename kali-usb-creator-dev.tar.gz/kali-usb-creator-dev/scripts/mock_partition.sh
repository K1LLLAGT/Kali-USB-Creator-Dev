#!/usr/bin/env bash
# mock_partition.sh — simulate partitioning by creating/formatting usb.img
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib_common.sh
source "${LIB_DIR:-$SCRIPT_DIR}/lib_common.sh"

: "${MOCK_DIR:?MOCK_DIR not set}"
: "${USB_IMG:?USB_IMG not set}"
: "${USB_IMG_SIZE:?USB_IMG_SIZE not set}"

require_cmd truncate mkfs.ext4 || exit 1

info "Mock partition: target image ${USB_IMG} (${USB_IMG_SIZE})"
run_cmd mkdir -p "$MOCK_DIR"

# Auto-backup any existing mock image before clobbering it.
if [[ -f "$USB_IMG" ]]; then
    backup="${MOCK_DIR}/usb_backup_$(date +%Y%m%d_%H%M%S).img"
    info "Existing image found; backing up to ${backup}"
    run_cmd cp -a "$USB_IMG" "$backup"
    symlog "🗄️" "Backed up existing usb.img -> $(basename "$backup")"
fi

run_cmd truncate -s "$USB_IMG_SIZE" "$USB_IMG"
run_cmd mkfs.ext4 -F -q "$USB_IMG"

symlog "💾" "Partition simulation complete"
ok "Mock partition done."
