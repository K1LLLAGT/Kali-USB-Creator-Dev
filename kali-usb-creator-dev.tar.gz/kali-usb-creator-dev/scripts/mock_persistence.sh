#!/usr/bin/env bash
# mock_persistence.sh — simulate a persistence overlay as persistence.img
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
# shellcheck source=lib_common.sh
source "${LIB_DIR:-$SCRIPT_DIR}/lib_common.sh"

: "${MOCK_DIR:?MOCK_DIR not set}"
: "${PERSIST_IMG:?PERSIST_IMG not set}"
: "${PERSIST_IMG_SIZE:?PERSIST_IMG_SIZE not set}"
PERSIST_LABEL="${PERSIST_LABEL:-persistence}"

require_cmd truncate mkfs.ext4 || exit 1

info "Mock persistence: ${PERSIST_IMG} (${PERSIST_IMG_SIZE}, label=${PERSIST_LABEL})"
run_cmd mkdir -p "$MOCK_DIR"
run_cmd truncate -s "$PERSIST_IMG_SIZE" "$PERSIST_IMG"
run_cmd mkfs.ext4 -F -q -L "$PERSIST_LABEL" "$PERSIST_IMG"

symlog "🧩" "Persistence simulation complete"
ok "Mock persistence done."
